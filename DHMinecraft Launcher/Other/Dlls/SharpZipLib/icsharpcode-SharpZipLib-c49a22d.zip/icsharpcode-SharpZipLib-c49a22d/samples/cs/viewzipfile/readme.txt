viewzipfile
-----------

Usage:


  viewzipfile [filename]

  will view the contents of the zipfile [filename]