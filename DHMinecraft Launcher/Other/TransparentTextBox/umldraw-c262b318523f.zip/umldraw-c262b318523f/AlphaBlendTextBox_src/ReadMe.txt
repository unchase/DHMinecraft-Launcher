Title:       AlphaBlendTextBox
Author:      Bob Bradley
Email:       ZBobb@hotmail.com
Environment: C# .NET 1.1, WinXP/2000/2003
Keywords:    Control
Level:       Intermediate&quot;
Description: A transparent/translucent textbox for .Net.
Section      C# Controls
SubSection   Edit Controls

Click on the AlphaBlendTextBox.sln and compile it first.

A big note: I have used Visual Studio .Net 2003 and .Net framework 1.1 to create this control and the sample projects.  I will repost a VS2002 .Net 1.0 version as soon as I can.