﻿namespace UMLDraw
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.новыйПроектToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.открытьПроектToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьПроектToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.правкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьОбъектToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.входToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.состояниеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.переходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.комментарийToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.размерРабочегоПоляToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.помощьПользователюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tSBNew = new System.Windows.Forms.ToolStripButton();
            this.tSBOpen = new System.Windows.Forms.ToolStripButton();
            this.tSBSave = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tSBIn = new System.Windows.Forms.ToolStripButton();
            this.tSBState = new System.Windows.Forms.ToolStripButton();
            this.tSBTransfer = new System.Windows.Forms.ToolStripButton();
            this.tSBOut = new System.Windows.Forms.ToolStripButton();
            this.tSBComment = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tSBHelp = new System.Windows.Forms.ToolStripButton();
            this.tPStructure = new System.Windows.Forms.TreeView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.правкаToolStripMenuItem,
            this.справкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(984, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новыйПроектToolStripMenuItem,
            this.открытьПроектToolStripMenuItem,
            this.сохранитьПроектToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // новыйПроектToolStripMenuItem
            // 
            this.новыйПроектToolStripMenuItem.Name = "новыйПроектToolStripMenuItem";
            this.новыйПроектToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.новыйПроектToolStripMenuItem.Text = "Новый проект";
            this.новыйПроектToolStripMenuItem.Click += new System.EventHandler(this.новыйПроектToolStripMenuItem_Click);
            // 
            // открытьПроектToolStripMenuItem
            // 
            this.открытьПроектToolStripMenuItem.Name = "открытьПроектToolStripMenuItem";
            this.открытьПроектToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.открытьПроектToolStripMenuItem.Text = "Открыть проект";
            this.открытьПроектToolStripMenuItem.Click += new System.EventHandler(this.открытьПроектToolStripMenuItem_Click);
            // 
            // сохранитьПроектToolStripMenuItem
            // 
            this.сохранитьПроектToolStripMenuItem.Name = "сохранитьПроектToolStripMenuItem";
            this.сохранитьПроектToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.сохранитьПроектToolStripMenuItem.Text = "Сохранить проект";
            this.сохранитьПроектToolStripMenuItem.Click += new System.EventHandler(this.сохранитьПроектToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // правкаToolStripMenuItem
            // 
            this.правкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьОбъектToolStripMenuItem,
            this.размерРабочегоПоляToolStripMenuItem});
            this.правкаToolStripMenuItem.Name = "правкаToolStripMenuItem";
            this.правкаToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.правкаToolStripMenuItem.Text = "Правка";
            // 
            // добавитьОбъектToolStripMenuItem
            // 
            this.добавитьОбъектToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.входToolStripMenuItem,
            this.состояниеToolStripMenuItem,
            this.переходToolStripMenuItem,
            this.выходToolStripMenuItem1,
            this.комментарийToolStripMenuItem});
            this.добавитьОбъектToolStripMenuItem.Name = "добавитьОбъектToolStripMenuItem";
            this.добавитьОбъектToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.добавитьОбъектToolStripMenuItem.Text = "Добавить объект";
            // 
            // входToolStripMenuItem
            // 
            this.входToolStripMenuItem.Name = "входToolStripMenuItem";
            this.входToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.входToolStripMenuItem.Text = "Вход";
            this.входToolStripMenuItem.Click += new System.EventHandler(this.входToolStripMenuItem_Click);
            // 
            // состояниеToolStripMenuItem
            // 
            this.состояниеToolStripMenuItem.Name = "состояниеToolStripMenuItem";
            this.состояниеToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.состояниеToolStripMenuItem.Text = "Состояние";
            this.состояниеToolStripMenuItem.Click += new System.EventHandler(this.состояниеToolStripMenuItem_Click);
            // 
            // переходToolStripMenuItem
            // 
            this.переходToolStripMenuItem.Name = "переходToolStripMenuItem";
            this.переходToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.переходToolStripMenuItem.Text = "Переход";
            this.переходToolStripMenuItem.Click += new System.EventHandler(this.переходToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem1
            // 
            this.выходToolStripMenuItem1.Name = "выходToolStripMenuItem1";
            this.выходToolStripMenuItem1.Size = new System.Drawing.Size(151, 22);
            this.выходToolStripMenuItem1.Text = "Выход";
            this.выходToolStripMenuItem1.Click += new System.EventHandler(this.выходToolStripMenuItem1_Click);
            // 
            // комментарийToolStripMenuItem
            // 
            this.комментарийToolStripMenuItem.Name = "комментарийToolStripMenuItem";
            this.комментарийToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.комментарийToolStripMenuItem.Text = "Комментарий";
            this.комментарийToolStripMenuItem.Click += new System.EventHandler(this.комментарийToolStripMenuItem_Click);
            // 
            // размерРабочегоПоляToolStripMenuItem
            // 
            this.размерРабочегоПоляToolStripMenuItem.Name = "размерРабочегоПоляToolStripMenuItem";
            this.размерРабочегоПоляToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.размерРабочегоПоляToolStripMenuItem.Text = "Размер рабочего поля";
            this.размерРабочегоПоляToolStripMenuItem.Click += new System.EventHandler(this.размерРабочегоПоляToolStripMenuItem_Click);
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.помощьПользователюToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // помощьПользователюToolStripMenuItem
            // 
            this.помощьПользователюToolStripMenuItem.Name = "помощьПользователюToolStripMenuItem";
            this.помощьПользователюToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.помощьПользователюToolStripMenuItem.Text = "Помощь пользователю";
            this.помощьПользователюToolStripMenuItem.Click += new System.EventHandler(this.помощьПользователюToolStripMenuItem_Click);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tSBNew,
            this.tSBOpen,
            this.tSBSave,
            this.toolStripSeparator1,
            this.tSBIn,
            this.tSBState,
            this.tSBTransfer,
            this.tSBOut,
            this.tSBComment,
            this.toolStripSeparator2,
            this.tSBHelp});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(984, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tSBNew
            // 
            this.tSBNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tSBNew.Image = global::UMLDraw.Properties.Resources.new_document;
            this.tSBNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tSBNew.Name = "tSBNew";
            this.tSBNew.Size = new System.Drawing.Size(23, 22);
            this.tSBNew.Text = "Новый проект";
            this.tSBNew.Click += new System.EventHandler(this.tSBNew_Click);
            // 
            // tSBOpen
            // 
            this.tSBOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tSBOpen.Image = global::UMLDraw.Properties.Resources.open;
            this.tSBOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tSBOpen.Name = "tSBOpen";
            this.tSBOpen.Size = new System.Drawing.Size(23, 22);
            this.tSBOpen.Text = "Открыть";
            this.tSBOpen.Click += new System.EventHandler(this.tSBOpen_Click);
            // 
            // tSBSave
            // 
            this.tSBSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tSBSave.Image = global::UMLDraw.Properties.Resources.save;
            this.tSBSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tSBSave.Name = "tSBSave";
            this.tSBSave.Size = new System.Drawing.Size(23, 22);
            this.tSBSave.Text = "Сохранить";
            this.tSBSave.Click += new System.EventHandler(this.tSBSave_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tSBIn
            // 
            this.tSBIn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tSBIn.Image = global::UMLDraw.Properties.Resources.composition;
            this.tSBIn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tSBIn.Name = "tSBIn";
            this.tSBIn.Size = new System.Drawing.Size(23, 22);
            this.tSBIn.Text = "Добавить элеммент \"вход\"";
            this.tSBIn.Click += new System.EventHandler(this.tSBIn_Click);
            // 
            // tSBState
            // 
            this.tSBState.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tSBState.Image = global::UMLDraw.Properties.Resources.public_const;
            this.tSBState.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tSBState.Name = "tSBState";
            this.tSBState.Size = new System.Drawing.Size(23, 22);
            this.tSBState.Text = "Добавить элеммент \"состояние\"";
            this.tSBState.Click += new System.EventHandler(this.tSBState_Click);
            // 
            // tSBTransfer
            // 
            this.tSBTransfer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tSBTransfer.Image = global::UMLDraw.Properties.Resources.association;
            this.tSBTransfer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tSBTransfer.Name = "tSBTransfer";
            this.tSBTransfer.Size = new System.Drawing.Size(23, 22);
            this.tSBTransfer.Text = "Добавить элеммент \"переход\"";
            this.tSBTransfer.Click += new System.EventHandler(this.tSBTransfer_Click);
            // 
            // tSBOut
            // 
            this.tSBOut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tSBOut.Image = global::UMLDraw.Properties.Resources.aggregation;
            this.tSBOut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tSBOut.Name = "tSBOut";
            this.tSBOut.Size = new System.Drawing.Size(23, 22);
            this.tSBOut.Text = "Добавить элеммент \"выход\"";
            this.tSBOut.Click += new System.EventHandler(this.tSBOut_Click);
            // 
            // tSBComment
            // 
            this.tSBComment.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tSBComment.Image = global::UMLDraw.Properties.Resources.note;
            this.tSBComment.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tSBComment.Name = "tSBComment";
            this.tSBComment.Size = new System.Drawing.Size(23, 22);
            this.tSBComment.Text = "Добавить элеммент \"комментарий\"";
            this.tSBComment.Click += new System.EventHandler(this.tSBComment_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tSBHelp
            // 
            this.tSBHelp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tSBHelp.Image = global::UMLDraw.Properties.Resources.help;
            this.tSBHelp.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tSBHelp.Name = "tSBHelp";
            this.tSBHelp.Size = new System.Drawing.Size(23, 22);
            this.tSBHelp.Text = "Справка";
            this.tSBHelp.Click += new System.EventHandler(this.tSBHelp_Click);
            // 
            // tPStructure
            // 
            this.tPStructure.BackColor = System.Drawing.SystemColors.Window;
            this.tPStructure.Location = new System.Drawing.Point(764, 0);
            this.tPStructure.Name = "tPStructure";
            this.tPStructure.Size = new System.Drawing.Size(220, 513);
            this.tPStructure.TabIndex = 2;
            this.tPStructure.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.tPStructure_PreviewKeyDown);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.tPStructure);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 49);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(984, 513);
            this.panel1.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(755, 507);
            this.panel3.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.SystemColors.Window;
            this.panel2.Controls.Add(this.shapeContainer1);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(2000, 2000);
            this.panel2.TabIndex = 3;
            this.panel2.Leave += new System.EventHandler(this.panel2_Leave);
            this.panel2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel2_ClickOn);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Size = new System.Drawing.Size(2000, 2000);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(984, 562);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(1000, 600);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem новыйПроектToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem открытьПроектToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьПроектToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem правкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьОбъектToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem входToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem состояниеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem переходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem комментарийToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem помощьПользователюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tSBNew;
        private System.Windows.Forms.ToolStripButton tSBOpen;
        private System.Windows.Forms.ToolStripButton tSBSave;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tSBIn;
        private System.Windows.Forms.ToolStripButton tSBState;
        private System.Windows.Forms.ToolStripButton tSBTransfer;
        private System.Windows.Forms.ToolStripButton tSBOut;
        private System.Windows.Forms.ToolStripButton tSBComment;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tSBHelp;
        private System.Windows.Forms.TreeView tPStructure;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ToolStripMenuItem размерРабочегоПоляToolStripMenuItem;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
    }
}