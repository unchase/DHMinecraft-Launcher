﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UMLDraw
{
    public partial class WorkPlaceSize : Form
    {
        public WorkPlaceSize()
        {
            InitializeComponent();
            numericUpDown1.Value = MainForm.WorkPlace.SizeOfWorkPlace.X;
            numericUpDown2.Value = MainForm.WorkPlace.SizeOfWorkPlace.Y;
            this.Refresh();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MainForm.WorkPlace.SizeOfWorkPlace.X = Convert.ToInt16(numericUpDown1.Value);
            MainForm.WorkPlace.SizeOfWorkPlace.Y = Convert.ToInt16(numericUpDown2.Value);
            this.Close();
        }
    }
}
