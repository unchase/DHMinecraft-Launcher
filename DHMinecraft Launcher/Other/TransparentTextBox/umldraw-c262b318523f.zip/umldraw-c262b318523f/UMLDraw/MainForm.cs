﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UMLDraw
{
    public partial class MainForm : Form
    {
        //объявление класса Рабочее поле
        public class WorkPlace
        {
            public string name = "WorkPlace";
            public int ActualState = 0;
            public int ActualTransfer = 0;
            public int ActualComment = 0;
            public string currentAction = "SelectItem";                 //текущее действие пользователя
            public TreeNode tree = new TreeNode("WorkPlace");
            public static Point SizeOfWorkPlace = Point.Empty;

            public WorkPlace()
            {
                name = "WorkPlace";
                ActualState = 0;
                ActualTransfer = 0;
                ActualComment = 0;
                currentAction = "SelectItem";
                tree.Name = "WorkPlace";
                tree.Text = "WorkPlace";
                SizeOfWorkPlace.X = 2000;
                SizeOfWorkPlace.Y = 2000;
            }
        }
        //объявление класса элемент Вход
        public class Input
        {
            public string name = "Input";
            public List<String> outputName = new List<String>();
            public TreeNode node = new TreeNode("Input");

            public PictureBox InputP = new PictureBox();

            public Point[] perimeterPoint = new Point[4];
            public PictureBox[] marks = new PictureBox[4];

            public Point Zero = Point.Empty;
            public Point Drag = Point.Empty;
            public Point Drop = Point.Empty;

            public Input()
            {
                name = "Input";
                node.Name = "Input";
                node.Text = "Input";
            }

            public void InputInitialize(string name,Panel panel, MouseEventArgs e)
            {
                //pictureBox
                InputP.Location = new System.Drawing.Point(e.X, e.Y);
                InputP.Name = name;
                InputP.Size = new Size(25, 25);
                InputP.Image = global::UMLDraw.Properties.Resources.Input;
                InputP.TabIndex = 0;
                InputP.BringToFront();
                this.InputP.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Gb_MouseMove);
                this.InputP.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Gb_MouseDown);
                this.InputP.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.Gb_PreviewKeyDown);
                this.InputP.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Gb_MouseUp);
                this.InputP.GotFocus += new EventHandler(InputP_GotFocus);
                this.InputP.LostFocus += new EventHandler(InputP_LostFocus);
                panel.Controls.Add(InputP);

                //perimetrPoint
                setPerimeterPoints(e.X, e.Y);

                for (int i = 0; i < 4; i++)
                {
                    InputP.Controls.Add(marks[i]);
                    marks[i] = new PictureBox();
                    marks[i].Location = perimeterPoint[i];
                    marks[i].Size = new Size(2, 2);
                    marks[i].BackColor = Color.Blue;
                    marks[i].Hide();
                    marks[i].TabIndex = 0;
                    marks[i].BringToFront();
                    panel.Controls.Add(marks[i]);
                    panel.Refresh();
                }

            }
            private void setPerimeterPoints(int X, int Y)
            {
                perimeterPoint[0] = new Point(X - 1 + InputP.Width / 2, Y - 2);
                perimeterPoint[1] = new Point(X - 2, Y + InputP.Height / 2);
                perimeterPoint[2] = new Point(X + InputP.Width, Y + InputP.Height / 2);
                perimeterPoint[3] = new Point(X - 1 + InputP.Width / 2, Y + InputP.Height);
            }

            private void Gb_MouseDown(object sender, MouseEventArgs e)
            {
                Control c = sender as Control;
                Zero = c.Location;

                Drag.X = Cursor.Position.X;
                Drag.Y = Cursor.Position.Y;
                c.Focus();
            }

            private void Gb_MouseMove(object sender, MouseEventArgs e)
            {
                Control c = sender as Control;
                if (e.Button == MouseButtons.Left)
                {
                    Drop.X = Zero.X + Cursor.Position.X - Drag.X;
                    Drop.Y = Zero.Y + Cursor.Position.Y - Drag.Y;
                    c.Location = Drop;

                    setPerimeterPoints(Drop.X, Drop.Y);
                    for (int i = 0; i < 4; i++)
                        marks[i].Location = perimeterPoint[i];
                    InputP.Refresh();
                }
            }

            private void Gb_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
            {
                Control c = sender as Control;
                if (e.KeyValue == 46)
                {
                    c.Dispose();
                    for (int i = 0; i < 4; i++)
                        this.marks[i].Dispose();
                    WPlace.tree.Nodes[c.Name].Remove();

                    for (int i = 0; i < this.outputName.Count(); i++)
                        try
                        {
                            WPlace.tree.Nodes[this.outputName[i]].Remove();
                            TFer[findList(this.outputName[i])].line.Dispose();
                        }
                        catch { }
                }
            }

            private int findList(string key)
            {
                int result = -1;
                for (int i = 0; i < TFer.Count(); i++)
                    if (TFer[i].line.Name == key)
                        result = i;
                return result;
            }
            private void Gb_MouseUp(object sender, MouseEventArgs e)
            {
                Control c = sender as Control;
                if (WPlace.currentAction == "AddTransfer")      //если добавляется новый элемент
                {
                    AppendTransfer(c);
                }
                if (WPlace.currentAction == "SelectItem")       //если перемещается существующий элемент
                {
                    if (TFer.Count() > 0)
                    {
                        RewriteTransfer(c);
                    }
                }
            }

            private void AppendTransfer(Control c)
            {
                int nP;
                if (TFer[TFer.Count() - 1].fromName == "Unknown")
                {
                    nP = NearestPoint(TFer[TFer.Count() - 1].line.X2, TFer[TFer.Count() - 1].line.Y2);
                    TFer[TFer.Count() - 1].line.X1 = this.perimeterPoint[nP].X;
                    TFer[TFer.Count() - 1].line.Y1 = this.perimeterPoint[nP].Y;
                    TFer[TFer.Count() - 1].fromName = c.Name;
                    this.outputName.Add(TFer[TFer.Count() - 1].line.Name);
                }
                else
                    if (TFer[TFer.Count() - 1].toName == "Unknown")
                    {
                        MessageBox.Show("Нельзя задать этот элемент");
                    }
            }
            private void RewriteTransfer(Control c)
            {
                for (int i = 0; i < TFer.Count; i++)
                    if (TFer[i].fromName == c.Name)
                    {
                        TFer[i].line.X1 = this.perimeterPoint[NearestPoint(TFer[i].line.X2, TFer[i].line.Y2)].X;
                        TFer[i].line.Y1 = this.perimeterPoint[NearestPoint(TFer[i].line.X2, TFer[i].line.Y2)].Y;
                    }
            }

            private void InputP_GotFocus(object sender, EventArgs e)
            {
                for (int i = 0; i < 4; i++)
                    this.marks[i].Show();
            }

            private void InputP_LostFocus(object sender, EventArgs e)
            {
                for (int i = 0; i < 4; i++)
                    this.marks[i].Hide();
            }

            private int NearestPoint(int X, int Y)
            {
                double min = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - perimeterPoint[0].X), 2) + System.Math.Pow(System.Math.Abs(Y - perimeterPoint[0].Y), 2));
                int minIndex = 0;

                for (int i = 1; i < 4; i++)
                {
                    double range = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - perimeterPoint[i].X), 2) + System.Math.Pow(System.Math.Abs(Y - perimeterPoint[i].Y), 2));
                    if (range < min)
                    {
                        min = range;
                        minIndex = i;
                    }
                }
                return minIndex;
            }
        }
        //объявление класса элемент Выход
        public class Output
        {
            public string name = "Output";
            public TreeNode node = new TreeNode("Output");
            public List<String> inputName = new List<String>();

            public PictureBox OutputP = new PictureBox();

            public Point[] perimeterPoint = new Point[4];
            public PictureBox[] marks = new PictureBox[4];

            public Point Zero = Point.Empty;
            public Point Drag = Point.Empty;
            public Point Drop = Point.Empty;

            public Output()
            {
                name = "Output";
                node.Name = "Output";
                node.Text = "Output";
            }

            public void OutputInitialize(string name, Panel panel, MouseEventArgs e)
            {
                //pictureBox
                OutputP.Location = new System.Drawing.Point(e.X, e.Y);
                OutputP.Name = name;
                OutputP.Size = new Size(25, 25);
                OutputP.Image = global::UMLDraw.Properties.Resources.Output;
                OutputP.TabIndex = 0;
                OutputP.BringToFront();
                this.OutputP.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Gb_MouseMove);
                this.OutputP.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Gb_MouseDown);
                this.OutputP.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.Gb_PreviewKeyDown);
                this.OutputP.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Gb_MouseUp);
                this.OutputP.GotFocus += new EventHandler(OutputP_GotFocus);
                this.OutputP.LostFocus += new EventHandler(OutputP_LostFocus);
                panel.Controls.Add(OutputP);
                //perimetrPoint
                setPerimeterPoints(e.X, e.Y);

                for (int i = 0; i < 4; i++)
                {
                    OutputP.Controls.Add(marks[i]);
                    marks[i] = new PictureBox();
                    marks[i].Location = perimeterPoint[i];
                    marks[i].Size = new Size(2, 2);
                    marks[i].BackColor = Color.Blue;
                    marks[i].Hide();
                    marks[i].TabIndex = 0;
                    marks[i].BringToFront();
                    panel.Controls.Add(marks[i]);
                    panel.Refresh();
                }

            }
            private void setPerimeterPoints(int X, int Y)
            {
                perimeterPoint[0] = new Point(X - 1 + OutputP.Width / 2, Y - 2);
                perimeterPoint[1] = new Point(X - 2, Y + OutputP.Height / 2);
                perimeterPoint[2] = new Point(X + OutputP.Width, Y + OutputP.Height / 2);
                perimeterPoint[3] = new Point(X - 1 + OutputP.Width / 2, Y + OutputP.Height);
            }

            private void Gb_MouseDown(object sender, MouseEventArgs e)
            {
                Control c = sender as Control;
                Zero = c.Location;

                Drag.X = Cursor.Position.X;
                Drag.Y = Cursor.Position.Y;
                c.Focus();
            }

            private void Gb_MouseMove(object sender, MouseEventArgs e)
            {
                Control c = sender as Control;
                if (e.Button == MouseButtons.Left)
                {
                    Drop.X = Zero.X + Cursor.Position.X - Drag.X;
                    Drop.Y = Zero.Y + Cursor.Position.Y - Drag.Y;
                    c.Location = Drop;

                    setPerimeterPoints(Drop.X, Drop.Y);
                    for (int i = 0; i < 4; i++)
                        marks[i].Location = perimeterPoint[i];
                    OutputP.Refresh();
                }
            }

            private void Gb_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
            {
                Control c = sender as Control;
                if (e.KeyValue == 46)
                {
                    c.Dispose();
                    for (int i = 0; i < 4; i++)
                        this.marks[i].Dispose();
                    WPlace.tree.Nodes[c.Name].Remove();

                    for (int i = 0; i < this.inputName.Count(); i++)
                        try
                        {
                            WPlace.tree.Nodes[this.inputName[i]].Remove();
                            TFer[findList(this.inputName[i])].line.Dispose();
                        }
                        catch { }
                }
            }
            private int findList(string key)
            {
                int result = -1;
                for (int i = 0; i < TFer.Count(); i++)
                    if (TFer[i].line.Name == key)
                        result = i;
                return result;
            }
            private void Gb_MouseUp(object sender, MouseEventArgs e)
            {
                Control c = sender as Control;
                if (WPlace.currentAction == "AddTransfer")      //если добавляется новый элемент
                {
                    AppendTransfer(c);
                }
                if (WPlace.currentAction == "SelectItem")       //если перемещается существующий элемент
                {
                    if (TFer.Count() > 0)
                    {
                        RewriteTransfer(c);
                    }
                }
            }

            private void AppendTransfer(Control c)
            {
                int nP;
                if (TFer[TFer.Count() - 1].fromName == "Unknown")
                {
                    MessageBox.Show("Нельзя задать этот элемент");
                }
                else
                    if (TFer[TFer.Count() - 1].toName == "Unknown")
                    {
                        nP = NearestPoint(TFer[TFer.Count() - 1].line.X1, TFer[TFer.Count() - 1].line.Y1);
                        TFer[TFer.Count() - 1].line.X2 = this.perimeterPoint[nP].X;
                        TFer[TFer.Count() - 1].line.Y2 = this.perimeterPoint[nP].Y;
                        TFer[TFer.Count() - 1].toName = c.Name;
                        this.inputName.Add(TFer[TFer.Count() - 1].line.Name);

                        //получив две точки, отрисовываем линию
                        TFer[TFer.Count() - 1].line.Show();
                        WPlace.currentAction = "SelectItem";
                    }
            }
            private void RewriteTransfer(Control c)
            {
                for (int i = 0; i < TFer.Count; i++)
                    if (TFer[i].toName == c.Name)
                    {
                        TFer[i].line.X2 = this.perimeterPoint[NearestPoint(TFer[i].line.X1, TFer[i].line.Y1)].X;
                        TFer[i].line.Y2 = this.perimeterPoint[NearestPoint(TFer[i].line.X1, TFer[i].line.Y1)].Y;
                    }
            }

            private void OutputP_GotFocus(object sender, EventArgs e)
            {
                for (int i = 0; i < 4; i++)
                    this.marks[i].Show();
            }

            private void OutputP_LostFocus(object sender, EventArgs e)
            {
                for (int i = 0; i < 4; i++)
                    this.marks[i].Hide();
            }

            private int NearestPoint(int X, int Y)
            {
                double min = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - perimeterPoint[0].X), 2) + System.Math.Pow(System.Math.Abs(Y - perimeterPoint[0].Y), 2));
                int minIndex = 0;

                for (int i = 1; i < 4; i++)
                {
                    double range = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - perimeterPoint[i].X), 2) + System.Math.Pow(System.Math.Abs(Y - perimeterPoint[i].Y), 2));
                    if (range < min)
                    {
                        min = range;
                        minIndex = i;
                    }
                }
                return minIndex;
            }
        }
        //объявление класса элемент Состояние
        public class State
        {
            public string name = "State";
            public List<String> inputName = new List<String>();
            public List<String> outputName = new List<String>();
            public TreeNode node = new TreeNode("State");

            public GroupBox stateBox = new GroupBox();
            public GroupBox borderLine = new GroupBox();
            public TextBox names = new TextBox();

            public Point[] perimeterPoint = new Point[4];
            public PictureBox[] marks = new PictureBox[4];

            public Point Zero = Point.Empty;
            public Point Drag = Point.Empty;
            public Point Drop = Point.Empty;

            public State()
            {
                name = "State";
                node.Name = "State";
                node.Text = "State";
            }

            public void InitializeState(string name, Panel panel, MouseEventArgs e)
            {
                // textBox
                this.stateBox.Controls.Add(names);
                names.Location = new System.Drawing.Point(e.X + 5, e.Y + 15);
                names.Name = name;
                names.Text = name;
                names.Multiline = true;
                names.Size = new System.Drawing.Size(90, 30);
                names.BorderStyle = BorderStyle.None;
                names.TabIndex = 0;
                names.BringToFront();
                this.names.Leave += new System.EventHandler(this.Name_Changed);
                panel.Controls.Add(names);

                // borderLine
                this.stateBox.Controls.Add(borderLine);
                borderLine.Location = new System.Drawing.Point(e.X+2, e.Y+50);
                borderLine.Name = name;
                borderLine.Size = new System.Drawing.Size(96, 2);
                borderLine.TabIndex = 0;
                borderLine.TabStop = false;
                borderLine.Text = "";
                borderLine.BringToFront();
                panel.Controls.Add(borderLine);

                // groupBox
                stateBox.Location = new System.Drawing.Point(e.X, e.Y);
                stateBox.Name = name;
                stateBox.Size = new System.Drawing.Size(100, 65);
                stateBox.TabIndex = 0;
                stateBox.TabStop = false;
                stateBox.Text = "";
                stateBox.BringToFront();
                this.stateBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Gb_MouseMove);
                this.stateBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Gb_MouseDown);
                this.stateBox.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.Gb_PreviewKeyDown);
                this.stateBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Gb_MouseUp);
                this.stateBox.GotFocus += new EventHandler(stateBox_GotFocus);
                this.stateBox.LostFocus += new EventHandler(stateBox_LostFocus);
                panel.Controls.Add(stateBox);

                //perimetrPoint
                setPerimeterPoints(e.X, e.Y);

                for (int i = 0; i < 4; i++)
                {
                    stateBox.Controls.Add(marks[i]);
                    marks[i] = new PictureBox();
                    marks[i].Location = perimeterPoint[i];
                    marks[i].Size = new Size(2, 2);
                    marks[i].BackColor = Color.Blue;
                    marks[i].Hide();
                    marks[i].TabIndex = 0;
                    marks[i].BringToFront();
                    panel.Controls.Add(marks[i]);
                    panel.Refresh();
                }

            }
            private void setPerimeterPoints(int X, int Y)
            {
                perimeterPoint[0] = new Point(X - 1 + stateBox.Width / 2, Y - 2);
                perimeterPoint[1] = new Point(X - 2, Y + stateBox.Height / 2);
                perimeterPoint[2] = new Point(X + stateBox.Width, Y + stateBox.Height / 2);
                perimeterPoint[3] = new Point(X - 1 + stateBox.Width / 2, Y + stateBox.Height);
            }
            private void Name_Changed(object sender, EventArgs e)
            {
                Control c = sender as Control;
                try
                {
                    WPlace.tree.Nodes[c.Name].Text = c.Text;
                    STate[Convert.ToInt16(c.Name.Remove(0, 5))].name = c.Text;
                }
                catch
                {
                    MessageBox.Show("error, ёптыж");
                }
            }
            private void Gb_MouseDown(object sender, MouseEventArgs e)
            {
                Control c = sender as Control;
                Zero = c.Location;

                Drag.X = Cursor.Position.X;
                Drag.Y = Cursor.Position.Y;
                c.Focus();
            }
            private void Gb_MouseMove(object sender, MouseEventArgs e)
            {
                Control c = sender as Control;
                if (e.Button == MouseButtons.Left)
                {
                    Drop.X = Zero.X + Cursor.Position.X - Drag.X;
                    Drop.Y = Zero.Y + Cursor.Position.Y - Drag.Y;
                    c.Location = Drop;
                    this.names.Location = new System.Drawing.Point(Drop.X + 5, Drop.Y + 15);
                    this.borderLine.Location = new System.Drawing.Point(Drop.X + 2, Drop.Y + 50);

                    setPerimeterPoints(Drop.X, Drop.Y);
                    for (int i = 0; i < 4; i++)
                        marks[i].Location = perimeterPoint[i];
                    stateBox.Refresh();
                    names.Refresh();
                    borderLine.Refresh();
                }
            }
            private void Gb_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
            {
                Control c = sender as Control;
                if (e.KeyValue == 46)
                {
                    c.Dispose();
                    this.names.Dispose();
                    this.borderLine.Dispose();
                    for (int i = 0; i < 4; i++)
                        this.marks[i].Dispose();
                    WPlace.tree.Nodes[c.Name].Remove();

                    for(int i = 0 ; i < this.inputName.Count() ; i ++)
                        try
                        {
                            WPlace.tree.Nodes[this.inputName[i]].Remove();
                            TFer[findList(this.inputName[i])].line.Dispose();
                        }
                        catch { }
                    for (int i = 0; i < this.outputName.Count(); i++)
                        try
                        {
                            WPlace.tree.Nodes[this.outputName[i]].Remove();
                            TFer[findList(this.outputName[i])].line.Dispose();
                        }
                        catch { }
                }
            }
            private int findList(string key)
            {
                int result = -1;
                for (int i = 0; i < TFer.Count(); i++)
                    if (TFer[i].line.Name == key)
                        result = i;
                return result;
            }
            private void Gb_MouseUp(object sender, MouseEventArgs e)
            {
                Control c = sender as Control;
                if (WPlace.currentAction == "AddTransfer")      //если добавляется новый элемент
                {
                    AppendTransfer(c);
                }
                if (WPlace.currentAction == "SelectItem")       //если перемещается существующий элемент
                {
                    if (TFer.Count() > 0)
                    {
                        RewriteTransfer(c);
                    }
                }
            }

            private void AppendTransfer(Control c)
            {
                int nP;
                if (TFer[TFer.Count() - 1].fromName == "Unknown")
                {
                    nP = NearestPoint(TFer[TFer.Count() - 1].line.X2, TFer[TFer.Count() - 1].line.Y2);
                    TFer[TFer.Count() - 1].line.X1 = this.perimeterPoint[nP].X;
                    TFer[TFer.Count() - 1].line.Y1 = this.perimeterPoint[nP].Y;
                    TFer[TFer.Count() - 1].fromName = c.Name;
                    this.outputName.Add(TFer[TFer.Count() - 1].line.Name);
                }
                else
                    if (TFer[TFer.Count() - 1].toName == "Unknown")
                    {
                        if (TFer[TFer.Count() - 1].fromName != c.Name)
                        {
                            nP = NearestPoint(TFer[TFer.Count() - 1].line.X1, TFer[TFer.Count() - 1].line.Y1);
                            TFer[TFer.Count() - 1].line.X2 = this.perimeterPoint[nP].X;
                            TFer[TFer.Count() - 1].line.Y2 = this.perimeterPoint[nP].Y;
                            TFer[TFer.Count() - 1].toName = c.Name;
                            this.inputName.Add(TFer[TFer.Count() - 1].line.Name);

                            //получив две точки, отрисовываем линию
                            TFer[TFer.Count() - 1].line.Show();
                            WPlace.currentAction = "SelectItem";
                        }
                        else
                        {
                            MessageBox.Show("Нельзя создать петлю");
                        }
                    }
            }
            private void RewriteTransfer(Control c)
            {
                for (int i = 0; i < TFer.Count; i++)
                    if (TFer[i].fromName == c.Name)
                    {
                        TFer[i].line.X1 = this.perimeterPoint[NearestPoint(TFer[i].line.X2, TFer[i].line.Y2)].X;
                        TFer[i].line.Y1 = this.perimeterPoint[NearestPoint(TFer[i].line.X2, TFer[i].line.Y2)].Y;
                    }
                    else
                        if (TFer[i].toName == c.Name)
                        {
                            TFer[i].line.X2 = this.perimeterPoint[NearestPoint(TFer[i].line.X1, TFer[i].line.Y1)].X;
                            TFer[i].line.Y2 = this.perimeterPoint[NearestPoint(TFer[i].line.X1, TFer[i].line.Y1)].Y;

                            //получив две точки, отрисовываем линию
                            TFer[i].line.Show();
                            WPlace.currentAction = "SelectItem";
                        }
            }

            private void stateBox_GotFocus(object sender, EventArgs e)
            {
                for (int i = 0; i < 4; i++)
                    this.marks[i].Show();
            }

            private void stateBox_LostFocus(object sender, EventArgs e)
            {
                for (int i = 0; i < 4; i++)
                    this.marks[i].Hide();
            }

            private int NearestPoint(int X, int Y)
            {
                double min = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - perimeterPoint[0].X), 2) + System.Math.Pow(System.Math.Abs(Y - perimeterPoint[0].Y), 2));
                int minIndex = 0;

                for (int i = 1; i < 4; i++)
                {
                    double range = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - perimeterPoint[i].X), 2) + System.Math.Pow(System.Math.Abs(Y - perimeterPoint[i].Y), 2));
                    if (range < min)
                    {
                        min = range;
                        minIndex = i;
                    }
                }
                return minIndex;
            }
        }
        //объявление класса элемент Переход
        public class Transfer
        {
            public string name = "Transfer";
            public string fromName = "Unknown";
            public string toName = "Unknown";
            public TreeNode node = new TreeNode("Transfer");
            public Microsoft.VisualBasic.PowerPacks.LineShape line = new Microsoft.VisualBasic.PowerPacks.LineShape();

            public Transfer()
            {
                name = "Transfer";
                fromName = "Unknown";
                toName = "Unknown";
                node.Name = "Transfer";
                node.Text = "Transfer";
            }

            public void InitializeTransfer(string name, Microsoft.VisualBasic.PowerPacks.ShapeContainer container)
            {
                line.Name = name;
                line.Hide();
                line.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.Tr_PreviewKeyDown);
                container.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
                line});
                line.EndPointChanged += new System.EventHandler(this.ChangeEnd);
                line.StartPointChanged += new System.EventHandler(this.ChangeStart);
            }
            private void Tr_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
            {
                Microsoft.VisualBasic.PowerPacks.LineShape c = sender as Microsoft.VisualBasic.PowerPacks.LineShape;
                if (e.KeyValue == 46)
                {
                    c.Dispose();
                    WPlace.tree.Nodes[c.Name].Remove();
                }
            }

            private void ChangeEnd(object sender, EventArgs e)
            {
                int X = this.line.X2;
                int Y = this.line.Y2;
                if (X != 0 && Y != 0)
                {
                    if (this.fromName.Contains("State"))
                    {
                        State From = STate[Convert.ToInt16(this.fromName.Replace("State",""))];
                        double min = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - From.perimeterPoint[0].X), 2) + System.Math.Pow(System.Math.Abs(Y - From.perimeterPoint[0].Y), 2));
                        int minIndex = 0;
                        for (int j = 1; j < 4; j++)
                        {
                            double range = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - From.perimeterPoint[j].X), 2) + System.Math.Pow(System.Math.Abs(Y - From.perimeterPoint[j].Y), 2));
                            if (range < min)
                            {
                                min = range;
                                minIndex = j;
                            }
                        }

                        this.line.X1 = From.perimeterPoint[minIndex].X;
                        this.line.Y1 = From.perimeterPoint[minIndex].Y;

                        this.line.Show();
                        From.stateBox.Refresh();
                        From.names.Refresh();
                        From.borderLine.Refresh();
                    }
                    else
                        if (this.fromName.Contains("Comment"))
                        {
                            Comment From = CMent[Convert.ToInt16(this.fromName.Replace("Comment", ""))];
                            double min = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - From.perimeterPoint[0].X), 2) + System.Math.Pow(System.Math.Abs(Y - From.perimeterPoint[0].Y), 2));
                            int minIndex = 0;
                            for (int j = 1; j < 4; j++)
                            {
                                double range = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - From.perimeterPoint[j].X), 2) + System.Math.Pow(System.Math.Abs(Y - From.perimeterPoint[j].Y), 2));
                                if (range < min)
                                {
                                    min = range;
                                    minIndex = j;
                                }
                            }

                            this.line.X1 = From.perimeterPoint[minIndex].X;
                            this.line.Y1 = From.perimeterPoint[minIndex].Y;

                            this.line.Show();
                            From.CommentP.Refresh();
                            From.names.Refresh();
                        }
                        else
                            if (this.fromName.Contains("Output"))
                            {
                                Output From = OPut;
                                double min = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - From.perimeterPoint[0].X), 2) + System.Math.Pow(System.Math.Abs(Y - From.perimeterPoint[0].Y), 2));
                                int minIndex = 0;
                                for (int j = 1; j < 4; j++)
                                {
                                    double range = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - From.perimeterPoint[j].X), 2) + System.Math.Pow(System.Math.Abs(Y - From.perimeterPoint[j].Y), 2));
                                    if (range < min)
                                    {
                                        min = range;
                                        minIndex = j;
                                    }
                                }

                                this.line.X1 = From.perimeterPoint[minIndex].X;
                                this.line.Y1 = From.perimeterPoint[minIndex].Y;

                                this.line.Show();
                                From.OutputP.Refresh();
                            }
                            else
                                if(this.fromName.Contains("Input"))
                                {
                                    Input From = IPut;
                                    double min = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - From.perimeterPoint[0].X), 2) + System.Math.Pow(System.Math.Abs(Y - From.perimeterPoint[0].Y), 2));
                                    int minIndex = 0;
                                    for (int j = 1; j < 4; j++)
                                    {
                                        double range = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - From.perimeterPoint[j].X), 2) + System.Math.Pow(System.Math.Abs(Y - From.perimeterPoint[j].Y), 2));
                                        if (range < min)
                                        {
                                            min = range;
                                            minIndex = j;
                                        }
                                }

                                this.line.X1 = From.perimeterPoint[minIndex].X;
                                this.line.Y1 = From.perimeterPoint[minIndex].Y;

                                this.line.Show();
                                From.InputP.Refresh();
                                }
                }
            }
            private void ChangeStart(object sender, EventArgs e)
            {
                int X = this.line.X1;
                int Y = this.line.Y1;

                if (X != 0 && Y != 0 && this.toName != "Unknown")
                {
                    if (this.toName.Contains("State"))
                    {
                        State To = STate[Convert.ToInt16(this.toName.Replace("State", ""))];
                        double min = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - To.perimeterPoint[0].X), 2) + System.Math.Pow(System.Math.Abs(Y - To.perimeterPoint[0].Y), 2));
                        int minIndex = 0;
                        for (int j = 1; j < 4; j++)
                        {
                            double range = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - To.perimeterPoint[j].X), 2) + System.Math.Pow(System.Math.Abs(Y - To.perimeterPoint[j].Y), 2));
                            if (range < min)
                            {
                                min = range;
                                minIndex = j;
                            }
                        }

                        this.line.X2 = To.perimeterPoint[minIndex].X;
                        this.line.Y2 = To.perimeterPoint[minIndex].Y;

                        this.line.Show();
                        To.stateBox.Refresh();
                        To.names.Refresh();
                        To.borderLine.Refresh();
                    }
                    else
                        if (this.toName.Contains("Comment"))
                        {
                            Comment To = CMent[Convert.ToInt16(this.toName.Replace("Comment", ""))];
                            double min = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - To.perimeterPoint[0].X), 2) + System.Math.Pow(System.Math.Abs(Y - To.perimeterPoint[0].Y), 2));
                            int minIndex = 0;
                            for (int j = 1; j < 4; j++)
                            {
                                double range = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - To.perimeterPoint[j].X), 2) + System.Math.Pow(System.Math.Abs(Y - To.perimeterPoint[j].Y), 2));
                                if (range < min)
                                {
                                    min = range;
                                    minIndex = j;
                                }
                            }

                            this.line.X2 = To.perimeterPoint[minIndex].X;
                            this.line.Y2 = To.perimeterPoint[minIndex].Y;

                            this.line.Show();
                            To.CommentP.Refresh();
                            To.names.Refresh();
                        }
                        else
                            if (this.toName.Contains("Output"))
                            {
                                Output To = OPut;
                                double min = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - To.perimeterPoint[0].X), 2) + System.Math.Pow(System.Math.Abs(Y - To.perimeterPoint[0].Y), 2));
                                int minIndex = 0;
                                for (int j = 1; j < 4; j++)
                                {
                                    double range = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - To.perimeterPoint[j].X), 2) + System.Math.Pow(System.Math.Abs(Y - To.perimeterPoint[j].Y), 2));
                                    if (range < min)
                                    {
                                        min = range;
                                        minIndex = j;
                                    }
                                }

                                this.line.X2 = To.perimeterPoint[minIndex].X;
                                this.line.Y2 = To.perimeterPoint[minIndex].Y;

                                this.line.Show();
                                To.OutputP.Refresh();
                            }
                            else
                                if (this.toName.Contains("Input"))
                                {
                                    Input To = IPut;
                                    double min = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - To.perimeterPoint[0].X), 2) + System.Math.Pow(System.Math.Abs(Y - To.perimeterPoint[0].Y), 2));
                                    int minIndex = 0;
                                    for (int j = 1; j < 4; j++)
                                    {
                                        double range = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - To.perimeterPoint[j].X), 2) + System.Math.Pow(System.Math.Abs(Y - To.perimeterPoint[j].Y), 2));
                                        if (range < min)
                                        {
                                            min = range;
                                            minIndex = j;
                                        }
                                    }

                                    this.line.X2 = To.perimeterPoint[minIndex].X;
                                    this.line.Y2 = To.perimeterPoint[minIndex].Y;

                                    this.line.Show();
                                    To.InputP.Refresh();
                                }
                }
            }
        }
        //объявление класса элемент Комментарий
        public class Comment
        {
            public string name = "Comment";
            public TreeNode node = new TreeNode("Comment");
            public List<String> inputName = new List<String>();
            public List<String> outputName = new List<String>();

            public PictureBox CommentP = new PictureBox();
            public TextBox names = new TextBox();
            public Point[] perimeterPoint = new Point[4];
            public PictureBox[] marks = new PictureBox[4];
  
            public Point Zero = Point.Empty;
            public Point Drag = Point.Empty;
            public Point Drop = Point.Empty;

            public Comment()
            {
                name = "Comment";
                node.Name = "Comment";
                node.Text = "Comment";
            }

            public void CommentInitialize(string name, Panel panel, MouseEventArgs e)
            {
                // textBox
                this.CommentP.Controls.Add(names);
                names.Location = new System.Drawing.Point(e.X+5, e.Y+5);
                names.Name = name;
                names.Text = name;
                names.Size = new System.Drawing.Size(110, 56);
                names.BorderStyle = BorderStyle.None;
                names.Multiline = true;
                names.TabIndex = 0;
                names.BringToFront();
                this.names.Leave += new System.EventHandler(this.Name_Changed);
                panel.Controls.Add(names);

                //pictureBox
                CommentP.Location = new System.Drawing.Point(e.X, e.Y);
                CommentP.Name = name;
                CommentP.Size = new Size(130, 66);
                CommentP.Image = global::UMLDraw.Properties.Resources.Comment;
                CommentP.TabIndex = 0;
                CommentP.BringToFront();
                this.CommentP.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Gb_MouseMove);
                this.CommentP.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Gb_MouseDown);
                this.CommentP.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.Gb_PreviewKeyDown);
                this.CommentP.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Gb_MouseUp);
                this.CommentP.GotFocus += new EventHandler(CommentP_GotFocus);
                this.CommentP.LostFocus += new EventHandler(CommentP_LostFocus);
                panel.Controls.Add(CommentP);
                //perimetrPoint
                setPerimeterPoints(e.X, e.Y);

                for (int i = 0; i < 4; i++)
                {
                    CommentP.Controls.Add(marks[i]);
                    marks[i] = new PictureBox();
                    marks[i].Location = perimeterPoint[i];
                    marks[i].Size = new Size(2, 2);
                    marks[i].BackColor = Color.Blue;
                    marks[i].Hide();
                    marks[i].TabIndex = 0;
                    marks[i].BringToFront();
                    panel.Controls.Add(marks[i]);
                    panel.Refresh();
                }

            }
            private void setPerimeterPoints(int X, int Y)
            {
                perimeterPoint[0] = new Point(X - 1 + CommentP.Width / 2, Y - 2);
                perimeterPoint[1] = new Point(X - 2, Y + CommentP.Height / 2);
                perimeterPoint[2] = new Point(X + CommentP.Width, Y + CommentP.Height / 2);
                perimeterPoint[3] = new Point(X - 1 + CommentP.Width / 2, Y + CommentP.Height);
            }

            private void Name_Changed(object sender, EventArgs e)
            {
                Control c = sender as Control;
                try
                {
                    if (c.Text.Count() > 10)
                        WPlace.tree.Nodes[c.Name].Text = c.Text.Remove(10);
                    else
                        WPlace.tree.Nodes[c.Name].Text = c.Text;
                    CMent[Convert.ToInt16(c.Name.Remove(0, 7))].name = c.Text;
                }
                catch
                {
                    MessageBox.Show("error, ёптыж");
                }

            }

            private void Gb_MouseDown(object sender, MouseEventArgs e)
            {
                Control c = sender as Control;
                Zero = c.Location;

                Drag.X = Cursor.Position.X;
                Drag.Y = Cursor.Position.Y;
                c.Focus();
            }

            private void Gb_MouseMove(object sender, MouseEventArgs e)
            {
                Control c = sender as Control;
                if (e.Button == MouseButtons.Left)
                {
                    Drop.X = Zero.X + Cursor.Position.X - Drag.X;
                    Drop.Y = Zero.Y + Cursor.Position.Y - Drag.Y;
                    c.Location = Drop;
                    this.names.Location = new System.Drawing.Point(Drop.X + 5, Drop.Y + 5);

                    setPerimeterPoints(Drop.X, Drop.Y);
                    for (int i = 0; i < 4; i++)
                        marks[i].Location = perimeterPoint[i];
                    CommentP.Refresh();
                    names.Refresh();
                }
            }

            private void Gb_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
            {
                Control c = sender as Control;
                if (e.KeyValue == 46)
                {
                    c.Dispose();
                    this.names.Dispose();
                    for (int i = 0; i < 4; i++)
                        this.marks[i].Dispose();
                    WPlace.tree.Nodes[c.Name].Remove();

                    for (int i = 0; i < this.inputName.Count(); i++)
                        try
                        {
                            WPlace.tree.Nodes[this.inputName[i]].Remove();
                            TFer[findList(this.inputName[i])].line.Dispose();
                        }
                        catch { }
                    for (int i = 0; i < this.outputName.Count(); i++)
                        try
                        {
                            WPlace.tree.Nodes[this.outputName[i]].Remove();
                            TFer[findList(this.outputName[i])].line.Dispose();
                        }
                        catch { }
                }
            }
            private int findList(string key)
            {
                int result = -1;
                for (int i = 0; i < TFer.Count(); i++)
                    if (TFer[i].line.Name == key)
                        result = i;
                return result;
            }
            private void Gb_MouseUp(object sender, MouseEventArgs e)
            {
                Control c = sender as Control;
                if (WPlace.currentAction == "AddTransfer")      //если добавляется новый элемент
                {
                    AppendTransfer(c);
                }
                if (WPlace.currentAction == "SelectItem")       //если перемещается существующий элемент
                {
                    if (TFer.Count() > 0)
                    {
                        RewriteTransfer(c);
                    }
                }
            }

            private void AppendTransfer(Control c)
            {
                int nP;
                if (TFer[TFer.Count() - 1].fromName == "Unknown")
                {
                    nP = NearestPoint(TFer[TFer.Count() - 1].line.X2, TFer[TFer.Count() - 1].line.Y2);
                    TFer[TFer.Count() - 1].line.X1 = this.perimeterPoint[nP].X;
                    TFer[TFer.Count() - 1].line.Y1 = this.perimeterPoint[nP].Y;
                    TFer[TFer.Count() - 1].line.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dot;
                    TFer[TFer.Count() - 1].fromName = c.Name;
                    this.outputName.Add(TFer[TFer.Count() - 1].line.Name);
                }
                else
                    if (TFer[TFer.Count() - 1].toName == "Unknown")
                    {
                        if (TFer[TFer.Count() - 1].fromName != c.Name)
                        {
                            nP = NearestPoint(TFer[TFer.Count() - 1].line.X1, TFer[TFer.Count() - 1].line.Y1);
                            TFer[TFer.Count() - 1].line.X2 = this.perimeterPoint[nP].X;
                            TFer[TFer.Count() - 1].line.Y2 = this.perimeterPoint[nP].Y;
                            TFer[TFer.Count() - 1].line.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                            TFer[TFer.Count() - 1].toName = c.Name;
                            this.inputName.Add(TFer[TFer.Count() - 1].line.Name);

                            //получив две точки, отрисовываем линию
                            TFer[TFer.Count() - 1].line.Show();
                            WPlace.currentAction = "SelectItem";
                        }
                        else
                        {
                            MessageBox.Show("Нельзя создать петлю");
                        }
                    }
            }
            private void RewriteTransfer(Control c)
            {
                for (int i = 0; i < TFer.Count; i++)
                    if (TFer[i].fromName == c.Name)
                    {
                        TFer[i].line.X1 = this.perimeterPoint[NearestPoint(TFer[i].line.X2, TFer[i].line.Y2)].X;
                        TFer[i].line.Y1 = this.perimeterPoint[NearestPoint(TFer[i].line.X2, TFer[i].line.Y2)].Y;
                    }
                    else
                        if (TFer[i].toName == c.Name)
                        {
                            TFer[i].line.X2 = this.perimeterPoint[NearestPoint(TFer[i].line.X1, TFer[i].line.Y1)].X;
                            TFer[i].line.Y2 = this.perimeterPoint[NearestPoint(TFer[i].line.X1, TFer[i].line.Y1)].Y;

                            //получив две точки, отрисовываем линию
                            TFer[i].line.Show();
                            WPlace.currentAction = "SelectItem";
                        }
            }

            private void CommentP_GotFocus(object sender, EventArgs e)
            {
                for (int i = 0; i < 4; i++)
                    this.marks[i].Show();
            }

            private void CommentP_LostFocus(object sender, EventArgs e)
            {
                for (int i = 0; i < 4; i++)
                    this.marks[i].Hide();
            }

            private int NearestPoint(int X, int Y)
            {
                double min = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - perimeterPoint[0].X), 2) + System.Math.Pow(System.Math.Abs(Y - perimeterPoint[0].Y), 2));
                int minIndex = 0;

                for (int i = 1; i < 4; i++)
                {
                    double range = System.Math.Sqrt(System.Math.Pow(System.Math.Abs(X - perimeterPoint[i].X), 2) + System.Math.Pow(System.Math.Abs(Y - perimeterPoint[i].Y), 2));
                    if (range < min)
                    {
                        min = range;
                        minIndex = i;
                    }
                }
                return minIndex;
            }
        }
        
        public static WorkPlace WPlace = new WorkPlace();
        public static Input IPut;
        public static Output OPut;
        public static List<State> STate = new List<State>();
        public static List<Transfer> TFer = new List<Transfer>();
        public static List<Comment> CMent = new List<Comment>();

        OpenFileDialog openFileDialog1 = new OpenFileDialog();      //диалог открытия файла
        SaveFileDialog saveFileDialog1 = new SaveFileDialog();      //диалог сохранения файла

        public MainForm()
        {
            SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            InitializeComponent();
            InitializeOpenFileDialog();
            InitializeSaveFileDialog();
            SetStartStatus();
        }
        //                                                  //
        // *****Управление свойствами рабочего поля*****    //
        //                                                  //
        private void SetStartStatus()
        {
            tPStructure.Enabled = false;
            правкаToolStripMenuItem.Enabled = false;
            tSBSave.Enabled = false;
            tSBIn.Enabled = false;
            tSBOut.Enabled = false;
            tSBState.Enabled = false;
            tSBTransfer.Enabled = false;
            tSBComment.Enabled = false;
            setupSize(0,0);
        }
        private void SetWorkStatus()
        {
            tPStructure.Enabled = true;
            правкаToolStripMenuItem.Enabled = true;
            tSBSave.Enabled = true;
            tSBIn.Enabled = true;
            tSBOut.Enabled = true;
            tSBState.Enabled = true;
            tSBTransfer.Enabled = true;
            tSBComment.Enabled = true;
            setupSize(WorkPlace.SizeOfWorkPlace.X, WorkPlace.SizeOfWorkPlace.Y);
        }
        private void InitializeOpenFileDialog()
        {
            this.openFileDialog1.Title = "Открыть";
            this.openFileDialog1.Filter = "All files (*.*)|*.*";
            this.openFileDialog1.Multiselect = false;
            this.saveFileDialog1.InitialDirectory = "C:\\";
        }
        private void InitializeSaveFileDialog()
        {
            this.saveFileDialog1.Title = "Сохранить";
            this.saveFileDialog1.Filter = "All files|*.*";
            this.saveFileDialog1.InitialDirectory = "C:\\";
        }
        private void setupSize(int X, int Y)
        {
            this.panel2.Height = Y;
            this.panel2.Width = X;
        }

        //                                                                  //
        // *****добавление и редактирование элементов рабочего поля*****    //
        //                                                                  //
        //обработчик добавления элемента
        private void panel2_ClickOn(object sender, MouseEventArgs e)
        {
            panel2.Focus();
            switch (WPlace.currentAction)
            {
                case "SelectItem":
                    break;
                case "AddInput":
                    if(Controls.Find("Input", true).Count() == 0)
                    {
                        IPut = new Input();
                        WPlace.tree.Nodes.Add(IPut.node);
                        tPStructure.Nodes.Clear();
                        tPStructure.Nodes.Add(WPlace.tree);
                        IPut.InputInitialize(IPut.name, panel2, e);
                        this.Refresh();
                        IPut.InputP.Show();
                    }
                    else
                    {
                        MessageBox.Show("Нельзя создать больше одной точки входа");
                    }
                    WPlace.currentAction = "SelectItem";
                    break;
                case "AddOutput":
                    if(Controls.Find("Output", true).Count() == 0)
                    {
                        OPut = new Output();
                        WPlace.tree.Nodes.Add(OPut.node);
                        tPStructure.Nodes.Clear();
                        tPStructure.Nodes.Add(WPlace.tree);
                        OPut.OutputInitialize(OPut.name, panel2, e);
                        this.Refresh();
                    }
                    else
                    {
                        MessageBox.Show("Нельзя создать больше одной точки выхода");
                    }
                    WPlace.currentAction = "SelectItem";
                    break;
                case "AddState":
                    State sBuff = new State();          //создаём экземпляр объекта Сomment
                    AppendToWorkPlace(e, sBuff);        //добавляем экземпляр объекта Сomment к классу WorkPlace
                    STate.Add(sBuff);                   //добавляем экземпляр объекта Сomment к классу Comment
                    WPlace.currentAction = "SelectItem";
                    break;
                case "AddTransfer":
                    //currentAction = "SelectItem";
                    break;
                case "AddComment":
                    Comment cBuff = new Comment();      //создаём экземпляр объекта Сomment
                    AppendToWorkPlace(e, cBuff);        //добавляем экземпляр объекта Сomment к классу WorkPlace 
                    CMent.Add(cBuff);                   //добавляем экземпляр объекта Сomment к классу Comment
                    WPlace.currentAction = "SelectItem";       
                    break;
            }

        }
        //добавление элемента на рабочее поле(на форму и в лист класса)
        private void AppendToWorkPlace(MouseEventArgs e, State sBuff)
        {
            sBuff.name += Convert.ToString(STate.Count());
            sBuff.node.Name += WPlace.ActualState;
            sBuff.node.Text += WPlace.ActualState;
            WPlace.ActualState++;
            WPlace.tree.Nodes.Add(sBuff.node);
            tPStructure.Nodes.Clear();
            tPStructure.Nodes.Add(WPlace.tree);
            sBuff.InitializeState(sBuff.name, panel2, e);
        }
        private void AppendToWorkPlace(MouseEventArgs e, Comment cBuff)
        {
            cBuff.name += Convert.ToString(CMent.Count());
            cBuff.node.Name += WPlace.ActualComment;
            cBuff.node.Text += WPlace.ActualComment;
            WPlace.ActualComment++;
            WPlace.tree.Nodes.Add(cBuff.node);
            tPStructure.Nodes.Clear();
            tPStructure.Nodes.Add(WPlace.tree);
            cBuff.CommentInitialize(cBuff.name, panel2, e);
        }
        private void AppendToWorkPlace(Transfer tBuff)
        {
            panel2.Focus();
            tBuff.name += Convert.ToString(TFer.Count());
            tBuff.node.Name += WPlace.ActualTransfer;
            tBuff.node.Text += WPlace.ActualTransfer;
            WPlace.ActualTransfer++;
            WPlace.tree.Nodes.Add(tBuff.node);
            tBuff.InitializeTransfer(tBuff.name, shapeContainer1);
        }
        //Удаление рабочего поля
        private void removeWorkPlace()
        {
            while (WPlace.tree.Nodes.Count > 0)
                removeControl(WPlace.tree.FirstNode.Name);
            WPlace.tree.Nodes.Clear();
            tPStructure.Nodes.Clear();
            WPlace.ActualComment = 0;
            CMent.Clear();
            WPlace.ActualState = 0;
            STate.Clear();
            WPlace.ActualTransfer = 0;
            TFer.Clear();
            SetStartStatus();
        }
        //Удаление выбранного контрола с рабочего поля
        private void removeControl(string key)
        {
            if (key.Contains("Transfer"))
            {
                TFer[Convert.ToInt16(key.Replace("Transfer", ""))].line.Dispose();
            }

            if (key.Contains("State"))
            {
                STate[Convert.ToInt16(key.Replace("State", ""))].stateBox.Dispose();
                STate[Convert.ToInt16(key.Replace("State", ""))].names.Dispose();
                STate[Convert.ToInt16(key.Replace("State", ""))].borderLine.Dispose();
                for (int i = 0; i < STate[Convert.ToInt16(key.Replace("State", ""))].inputName.Count(); i++)
                {
                    try
                    {
                        TFer[Convert.ToInt16(STate[Convert.ToInt16(key.Replace("State", ""))].inputName[i].Replace("Transfer", ""))].line.Dispose();
                        WPlace.tree.Nodes[STate[Convert.ToInt16(key.Replace("State", ""))].inputName[i]].Remove();
                    }
                    catch { }
                }
                for (int i = 0; i < STate[Convert.ToInt16(key.Replace("State", ""))].outputName.Count(); i++)
                {
                    try
                    {
                        TFer[Convert.ToInt16(STate[Convert.ToInt16(key.Replace("State", ""))].outputName[i].Replace("Transfer", ""))].line.Dispose();
                        WPlace.tree.Nodes[STate[Convert.ToInt16(key.Replace("State", ""))].outputName[i]].Remove();
                    }
                    catch { }
                }
                    
            }
            if (key.Contains("Comment"))
            {
                CMent[Convert.ToInt16(key.Replace("Comment", ""))].CommentP.Dispose();
                CMent[Convert.ToInt16(key.Replace("Comment", ""))].names.Dispose();
                for (int i = 0; i < CMent[Convert.ToInt16(key.Replace("Comment", ""))].inputName.Count(); i++)
                {
                    try
                    {
                        TFer[Convert.ToInt16(CMent[Convert.ToInt16(key.Replace("Comment", ""))].inputName[i].Replace("Transfer", ""))].line.Dispose();
                        WPlace.tree.Nodes[CMent[Convert.ToInt16(key.Replace("Comment", ""))].inputName[i]].Remove();
                    }
                    catch { }
                }
                for (int i = 0; i < CMent[Convert.ToInt16(key.Replace("Comment", ""))].outputName.Count(); i++)
                {
                    try
                    {
                        TFer[Convert.ToInt16(CMent[Convert.ToInt16(key.Replace("Comment", ""))].outputName[i].Replace("Transfer", ""))].line.Dispose();
                        WPlace.tree.Nodes[CMent[Convert.ToInt16(key.Replace("Comment", ""))].outputName[i]].Remove();
                    }
                    catch { }
                }
            }
            if (key.Contains("Input"))
            {
                IPut.InputP.Dispose();
                for (int i = 0; i < IPut.outputName.Count(); i++)
                {
                    try
                    {
                        TFer[Convert.ToInt16(IPut.outputName[i].Replace("Transfer", ""))].line.Dispose();
                        WPlace.tree.Nodes[IPut.outputName[i]].Remove();
                    }
                    catch { }
                }
            }
            if (key.Contains("Output"))
            {
                OPut.OutputP.Dispose();
                for (int i = 0; i < OPut.inputName.Count(); i++)
                {
                    try
                    {
                        TFer[Convert.ToInt16(OPut.inputName[i].Replace("Transfer", ""))].line.Dispose();
                        WPlace.tree.Nodes[OPut.inputName[i]].Remove();
                    }
                    catch { }
                }
            }
            WPlace.tree.Nodes[key].Remove();
        }
        //Удаление выбранного элемента
        private void tPStructure_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            int count = tPStructure.GetNodeCount(true);
            if (tPStructure.SelectedNode != null)
            {
                if (e.KeyValue == 46) 
                {
                    string name = tPStructure.SelectedNode.Name;
                    if (name.Contains("WorkPlace"))
                        removeWorkPlace();
                    else
                        removeControl(name);
                }
            }
        }
        //сброс текущей операции добавления елемента
        private void panel2_Leave(object sender, EventArgs e)
        {
            WPlace.currentAction = "SelectItem";
        }

        //                                                                  //
        // *****вызовы элементов текстового меню и панели инструментов***** //
        //                                                                  //
        //добавление элемента вход
        private void tSBIn_Click(object sender, EventArgs e)
        {
            WPlace.currentAction = "AddInput";
        }
        private void входToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WPlace.currentAction = "AddInput";
        }
        //добавление элемента состояние
        private void tSBState_Click(object sender, EventArgs e)
        {
            WPlace.currentAction = "AddState";
        }
        private void состояниеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WPlace.currentAction = "AddState";
        }
        //добавление элемента переход
        private void tSBTransfer_Click(object sender, EventArgs e)
        {
            WPlace.currentAction = "AddTransfer";
            Transfer tBuff = new Transfer();
            AppendToWorkPlace(tBuff);
            TFer.Add(tBuff);
        }
        private void переходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WPlace.currentAction = "AddTransfer";
            Transfer tBuff = new Transfer();
            AppendToWorkPlace(tBuff);
            TFer.Add(tBuff);
        }
        //добавление элемента выход
        private void tSBOut_Click(object sender, EventArgs e)
        {
            WPlace.currentAction = "AddOutput";
        }
        private void выходToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            WPlace.currentAction = "AddOutput";
        }
        //добавление элемента комментарий
        private void tSBComment_Click(object sender, EventArgs e)
        {
            WPlace.currentAction = "AddComment";
        }
        private void комментарийToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WPlace.currentAction = "AddComment";
        }
        //создание нового проекта
        private void tSBNew_Click(object sender, EventArgs e)
        {
            removeWorkPlace();
            tPStructure.Nodes.Add(WPlace.tree);
            SetWorkStatus();
        }
        private void новыйПроектToolStripMenuItem_Click(object sender, EventArgs e)
        {
            removeWorkPlace();
            tPStructure.Nodes.Add(WPlace.tree);
            SetWorkStatus();
        }
        //изменение размера рабочего поля
        private void размерРабочегоПоляToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WorkPlaceSize dialog = new WorkPlaceSize();
            DialogResult resulr = dialog.ShowDialog();
            setupSize(WorkPlace.SizeOfWorkPlace.X, WorkPlace.SizeOfWorkPlace.Y);
        }
        //выход из программы
        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //вывод информации о программе
        private void tSBHelp_Click(object sender, EventArgs e)
        {
            UserManual dialog = new UserManual();
            DialogResult resulr = dialog.ShowDialog();
        }
        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UserManual dialog = new UserManual();
            DialogResult resulr = dialog.ShowDialog();
        }
        //вывод справки
        private void помощьПользователюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Отче наш, Иже еси на Небесех! Да святится имя Твое, да приидет Царствие Твое, да будет воля Твоя, яко на Небеси и на земли. Хлеб наш насущный даждь нам днесь; и остави нам долги наша, якоже и мы оставляем должником нашим; и не введи нас во искушение,но избави нас от лукавого, Яко Твое есть Царство, и сила, и слава во веки. Аминь.");
        }
        //сохранение проекта
        private void tSBSave_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
            }
        }
        private void сохранитьПроектToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
            }
        }
        //открытие проекта
        private void tSBOpen_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                SetWorkStatus();
            }
        }
        private void открытьПроектToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                SetWorkStatus();
            }
        }
    }
}
